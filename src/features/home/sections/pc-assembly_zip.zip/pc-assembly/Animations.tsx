"use client";

import { useRef } from "react";
import type { MutableRefObject } from "react";

export type Vec3 = [number, number, number];

export interface ElapsedState {
  startTime: number;
  started: boolean;
}

export type ElapsedRef = MutableRefObject<ElapsedState>;

export function useElapsedRef(): ElapsedRef {
  return useRef<ElapsedState>({ startTime: 0, started: false });
}

export type EasingName = "outCubic" | "outBack" | "outExpo" | "linear";

function easeLinear(t: number): number {
  return t;
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

function easeOutExpo(t: number): number {
  return t >= 1 ? 1 : 1 - Math.pow(2, -10 * t);
}

function easeOutBack(t: number): number {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
}

export function getEasing(name: EasingName | undefined): (t: number) => number {
  switch (name) {
    case "outBack":
      return easeOutBack;
    case "outExpo":
      return easeOutExpo;
    case "linear":
      return easeLinear;
    case "outCubic":
    default:
      return easeOutCubic;
  }
}

export interface Transform {
  position: Vec3;
  rotation: Vec3;
  scale: number;
}

export interface Stage {
  delay: number;
  duration: number;
  easing?: EasingName;
}

export interface FadeStage extends Stage {
  from: number;
  to: number;
}

export interface SpinConfig {
  axis: "x" | "y" | "z";
  speed: number; // radians per second
}

export interface PartAnimationConfig {
  id: string;
  path: string;
  start: Transform;
  end: Transform;
  arrival: Stage;
  fades?: FadeStage[];
  glow?: boolean;
  glowColor?: string;
  spin?: SpinConfig;
  castShadow?: boolean;
}

// --- Global timeline constants ---------------------------------------
export const CLOSE_START = 6.9;
export const CLOSE_DURATION = 0.9;
export const GLOW_START = 7.3;
export const READY_TEXT_START = 8.2;
export const TOTAL_DURATION = 9.2;

// NOTE: All position/rotation/scale numbers below are STARTING
// placeholders assuming a roughly normalized ~2-unit interior once each
// GLB is centered at its own origin. Sketchfab exports vary wildly in
// scale/pivot — expect to hand-tune these per your actual assets
// (your own testing already showed cabinet.glb needing a tiny scale
// like 0.005-0.02 while other parts sat closer to 1).
export const ASSEMBLY_SEQUENCE: PartAnimationConfig[] = [
  {
    id: "cabinet",
    path: "/models/cabinet.glb",
    start: { position: [0, -1.6, -3], rotation: [0, 0.15, 0], scale: 0.02 },
    end: { position: [0, -0.55, 0], rotation: [0, 0, 0], scale: 0.02 },
    arrival: { delay: 0, duration: 1.1, easing: "outCubic" },
    fades: [
      { delay: 0, duration: 0.6, from: 0, to: 0.32 },
      { delay: CLOSE_START, duration: CLOSE_DURATION, from: 0.32, to: 1 },
    ],
    glow: false,
  },
  {
    id: "motherboard",
    path: "/models/motherboard.glb",
    start: { position: [-3.4, 0.3, -1.6], rotation: [0, 0.7, 0], scale: 1 },
    end: { position: [0, -0.1, -0.1], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 0.85, duration: 0.95, easing: "outBack" },
    fades: [{ delay: 0.85, duration: 0.4, from: 0, to: 1 }],
    glow: true,
    glowColor: "#38bdf8",
  },
  {
    id: "cpu",
    path: "/models/cpu.glb",
    start: { position: [0, 3.2, -0.4], rotation: [0.5, 0, 0], scale: 1 },
    end: { position: [0, 0.08, 0.1], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 1.85, duration: 0.6, easing: "outBack" },
    fades: [{ delay: 1.85, duration: 0.3, from: 0, to: 1 }],
    glow: true,
    glowColor: "#22d3ee",
  },
  {
    id: "ram1",
    path: "/models/ram.glb",
    start: { position: [2.6, 2.4, -1.2], rotation: [0, 0, 0.4], scale: 1 },
    end: { position: [0.42, 0.22, -0.15], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 2.5, duration: 0.5, easing: "outBack" },
    fades: [{ delay: 2.5, duration: 0.25, from: 0, to: 1 }],
    glow: true,
    glowColor: "#3b82f6",
  },
  {
    id: "ram2",
    path: "/models/ram.glb",
    start: { position: [2.9, 2.7, -1.2], rotation: [0, 0, 0.4], scale: 1 },
    end: { position: [0.58, 0.22, -0.15], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 2.75, duration: 0.5, easing: "outBack" },
    fades: [{ delay: 2.75, duration: 0.25, from: 0, to: 1 }],
    glow: true,
    glowColor: "#3b82f6",
  },
  {
    id: "ssd",
    path: "/models/ssd.glb",
    start: { position: [-2.6, -1.8, -1.2], rotation: [0.4, 0, 0], scale: 1 },
    end: { position: [-0.5, -0.22, 0.28], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 3.35, duration: 0.55, easing: "outBack" },
    fades: [{ delay: 3.35, duration: 0.3, from: 0, to: 1 }],
    glow: true,
    glowColor: "#0ea5e9",
  },
  {
    id: "gpu",
    path: "/models/gpu.glb",
    start: { position: [3.6, -0.3, -0.8], rotation: [0, -0.5, 0], scale: 1 },
    end: { position: [0, -0.3, 0.42], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 4, duration: 0.75, easing: "outBack" },
    fades: [{ delay: 4, duration: 0.35, from: 0, to: 1 }],
    glow: true,
    glowColor: "#06b6d4",
  },
  {
    id: "psu",
    path: "/models/psu.glb",
    start: { position: [-3.6, -1.6, -0.6], rotation: [0, 0.4, 0], scale: 1 },
    end: { position: [-0.75, -0.85, -0.35], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 4.85, duration: 0.6, easing: "outBack" },
    fades: [{ delay: 4.85, duration: 0.3, from: 0, to: 1 }],
    glow: false,
  },
  {
    id: "fan",
    path: "/models/fan.glb",
    start: { position: [0, 3.2, 1.6], rotation: [0.7, 0, 0], scale: 1 },
    end: { position: [0, 0.75, 0.55], rotation: [0, 0, 0], scale: 1 },
    arrival: { delay: 5.55, duration: 0.55, easing: "outBack" },
    fades: [{ delay: 5.55, duration: 0.3, from: 0, to: 1 }],
    glow: true,
    glowColor: "#38bdf8",
    spin: { axis: "z", speed: 3.2 },
  },
];

/**
 * Resolves the current opacity for a part given elapsed scene time and its
 * (ordered, non-overlapping) fade stages. Before the first stage starts,
 * returns that stage's `from` value. After each stage completes, its `to`
 * value becomes the baseline until the next stage begins.
 */
export function resolveFadeOpacity(elapsed: number, fades?: FadeStage[]): number {
  if (!fades || fades.length === 0) return 1;

  let opacity = fades[0].from;

  for (const fade of fades) {
    if (elapsed <= fade.delay) {
      break;
    }
    const localT = Math.min(Math.max((elapsed - fade.delay) / fade.duration, 0), 1);
    const eased = getEasing(fade.easing ?? "outCubic")(localT);
    opacity = fade.from + (fade.to - fade.from) * eased;
  }

  return opacity;
}