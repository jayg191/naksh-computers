"use client";

import { useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { PerspectiveCamera } from "@react-three/drei";
import * as THREE from "three";
import { TOTAL_DURATION, type ElapsedRef } from "./Animations";

interface CameraRigProps {
  play: boolean;
  elapsedRef: ElapsedRef;
}

interface CameraPreset {
  startZ: number;
  endZ: number;
  y: number;
  fov: number;
  orbitRadius: number;
}

export default function CameraRig({ play, elapsedRef }: CameraRigProps) {
  const camRef = useRef<THREE.PerspectiveCamera>(null);
  const { size } = useThree();

  const preset: CameraPreset = useMemo(() => {
    if (size.width < 640) {
      return { startZ: 9.5, endZ: 7.6, y: 0.4, fov: 46, orbitRadius: 0.25 };
    }
    if (size.width < 1024) {
      return { startZ: 8.8, endZ: 6.9, y: 0.55, fov: 42, orbitRadius: 0.35 };
    }
    return { startZ: 8, endZ: 6.1, y: 0.7, fov: 36, orbitRadius: 0.45 };
  }, [size.width]);

  useFrame((state, delta) => {
    const cam = camRef.current;
    if (!cam) return;

    if (!play) {
      cam.position.set(0, preset.y, preset.startZ);
      cam.lookAt(0, 0, 0);
      return;
    }

    const elapsed = elapsedRef.current.started
      ? state.clock.elapsedTime - elapsedRef.current.startTime
      : 0;

    const zoomT = THREE.MathUtils.clamp(elapsed / TOTAL_DURATION, 0, 1);
    const zoomEased = 1 - Math.pow(1 - zoomT, 2);

    const targetZ = THREE.MathUtils.lerp(preset.startZ, preset.endZ, zoomEased);
    const targetX = Math.sin(elapsed * 0.18) * preset.orbitRadius;
    const targetY = preset.y + Math.sin(elapsed * 0.12) * 0.06;

    const smoothing = 1 - Math.exp(-delta * 2.4);

    cam.position.x = THREE.MathUtils.lerp(cam.position.x, targetX, smoothing);
    cam.position.y = THREE.MathUtils.lerp(cam.position.y, targetY, smoothing);
    cam.position.z = THREE.MathUtils.lerp(cam.position.z, targetZ, smoothing);

    cam.lookAt(0, 0.05, 0.1);
  });

  return (
    <PerspectiveCamera
      ref={camRef}
      makeDefault
      fov={preset.fov}
      position={[0, preset.y, preset.startZ]}
      near={0.1}
      far={50}
    />
  );
}