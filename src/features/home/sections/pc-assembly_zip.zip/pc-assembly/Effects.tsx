"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { Sparkles, Text } from "@react-three/drei";
import * as THREE from "three";

interface ParticleFieldProps {
  active: boolean;
}

export function ParticleField({ active }: ParticleFieldProps) {
  const opacityRef = useRef(0);
  const groupRef = useRef<THREE.Group>(null);

  useFrame((_state, delta) => {
    opacityRef.current = THREE.MathUtils.lerp(opacityRef.current, active ? 1 : 0, delta * 2);
    if (groupRef.current) {
      groupRef.current.visible = opacityRef.current > 0.02;
    }
  });

  return (
    <group ref={groupRef}>
      <Sparkles
        count={70}
        scale={[2.6, 3.2, 2.2]}
        size={2.2}
        speed={0.28}
        color="#38bdf8"
        opacity={0.7}
        position={[0, 0.3, 0]}
      />
      <Sparkles
        count={30}
        scale={[1.8, 2.2, 1.8]}
        size={3.2}
        speed={0.15}
        color="#818cf8"
        opacity={0.45}
        position={[0, 0.3, 0]}
      />
    </group>
  );
}

interface RGBPulseLightProps {
  active: boolean;
}

const PULSE_COLORS = ["#38bdf8", "#6366f1", "#22d3ee", "#3b82f6"];

export function RGBPulseLight({ active }: RGBPulseLightProps) {
  const lightRef = useRef<THREE.PointLight>(null);
  const intensityRef = useRef(0);
  const color = useMemo(() => new THREE.Color(), []);
  const nextColor = useMemo(() => new THREE.Color(), []);

  useFrame((state, delta) => {
    const light = lightRef.current;
    if (!light) return;

    intensityRef.current = THREE.MathUtils.lerp(
      intensityRef.current,
      active ? 2.2 : 0,
      delta * 2.2
    );

    const t = state.clock.elapsedTime * 0.6;
    const colorIndex = Math.floor(t) % PULSE_COLORS.length;
    const upcomingIndex = (colorIndex + 1) % PULSE_COLORS.length;
    const localT = t - Math.floor(t);

    color.set(PULSE_COLORS[colorIndex]);
    nextColor.set(PULSE_COLORS[upcomingIndex]);
    color.lerp(nextColor, localT);

    light.color.copy(color);
    light.intensity =
      intensityRef.current * (0.75 + 0.25 * Math.sin(state.clock.elapsedTime * 3));
  });

  return <pointLight ref={lightRef} position={[0, 0.6, 0.8]} distance={4} decay={2} />;
}

interface SystemReadyTextProps {
  visible: boolean;
}

export function SystemReadyText({ visible }: SystemReadyTextProps) {
  const groupRef = useRef<THREE.Group>(null);
  const progressRef = useRef(0);

  useFrame((_state, delta) => {
    progressRef.current = THREE.MathUtils.lerp(progressRef.current, visible ? 1 : 0, delta * 2.5);

    const group = groupRef.current;
    if (!group) return;

    group.visible = progressRef.current > 0.02;
    group.scale.setScalar(0.9 + progressRef.current * 0.1);
    group.position.y = 1.55 + (1 - progressRef.current) * 0.15;
  });

  return (
    <group ref={groupRef} position={[0, 1.55, 0.85]}>
      <Text fontSize={0.2} color="#5eead4" anchorX="center" anchorY="middle" letterSpacing={0.18}>
        SYSTEM READY
      </Text>
    </group>
  );
}