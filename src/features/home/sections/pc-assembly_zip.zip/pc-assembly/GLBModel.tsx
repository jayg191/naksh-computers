"use client";

import { useEffect, useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import { useGLTF } from "@react-three/drei";
import * as THREE from "three";
import {
  getEasing,
  resolveFadeOpacity,
  type ElapsedRef,
  type PartAnimationConfig,
  type SpinConfig,
  type Transform,
} from "./Animations";

interface GLBModelProps {
  config: PartAnimationConfig;
  elapsedRef: ElapsedRef;
  play: boolean;
  glowActive: boolean;
}

interface TrackedMaterial {
  material: THREE.Material;
  standard?: THREE.MeshStandardMaterial;
  baseEmissive?: THREE.Color;
  baseEmissiveIntensity?: number;
}

const scratchColor = new THREE.Color();

function lerpTransform(
  target: THREE.Object3D,
  start: Transform,
  end: Transform,
  t: number,
  easing: (t: number) => number
) {
  const eased = easing(t);

  target.position.set(
    THREE.MathUtils.lerp(start.position[0], end.position[0], eased),
    THREE.MathUtils.lerp(start.position[1], end.position[1], eased),
    THREE.MathUtils.lerp(start.position[2], end.position[2], eased)
  );

  target.rotation.set(
    THREE.MathUtils.lerp(start.rotation[0], end.rotation[0], eased),
    THREE.MathUtils.lerp(start.rotation[1], end.rotation[1], eased),
    THREE.MathUtils.lerp(start.rotation[2], end.rotation[2], eased)
  );

  target.scale.setScalar(THREE.MathUtils.lerp(start.scale, end.scale, eased));
}

function applySpin(target: THREE.Object3D, spin: SpinConfig, delta: number) {
  target.rotation[spin.axis] += spin.speed * delta;
}

export default function GLBModel({ config, elapsedRef, play, glowActive }: GLBModelProps) {
  const groupRef = useRef<THREE.Group>(null);
  const arrivedRef = useRef(false);
  const materialsRef = useRef<TrackedMaterial[]>([]);

  const { scene } = useGLTF(config.path);
  const cloned = useMemo(() => scene.clone(true), [scene]);

  useEffect(() => {
    const tracked: TrackedMaterial[] = [];

    cloned.traverse((child) => {
      if (!(child instanceof THREE.Mesh)) return;

      child.castShadow = config.castShadow ?? true;
      child.receiveShadow = true;

      const sourceMaterials = Array.isArray(child.material)
        ? child.material
        : [child.material];

      const clonedMaterials = sourceMaterials.map((mat) => {
        const clonedMat = mat.clone();
        clonedMat.transparent = true;
        return clonedMat;
      });

      child.material = Array.isArray(child.material)
        ? clonedMaterials
        : clonedMaterials[0];

      for (const mat of clonedMaterials) {
        const isStandard = mat instanceof THREE.MeshStandardMaterial;
        tracked.push({
          material: mat,
          standard: isStandard ? (mat as THREE.MeshStandardMaterial) : undefined,
          baseEmissive: isStandard
            ? (mat as THREE.MeshStandardMaterial).emissive.clone()
            : undefined,
          baseEmissiveIntensity: isStandard
            ? (mat as THREE.MeshStandardMaterial).emissiveIntensity
            : undefined,
        });
      }
    });

    materialsRef.current = tracked;

    return () => {
      for (const { material } of tracked) {
        material.dispose();
      }
    };
  }, [cloned, config.castShadow]);

  const easing = useMemo(() => getEasing(config.arrival.easing), [config.arrival.easing]);

  useFrame((state, delta) => {
    const group = groupRef.current;
    if (!group) return;

    if (!play) {
      lerpTransform(group, config.start, config.end, 0, easing);
      for (const t of materialsRef.current) {
        t.material.opacity = resolveFadeOpacity(0, config.fades);
        if (t.standard && t.baseEmissive && t.baseEmissiveIntensity !== undefined) {
          t.standard.emissive.copy(t.baseEmissive);
          t.standard.emissiveIntensity = t.baseEmissiveIntensity;
        }
      }
      return;
    }

    const elapsed = elapsedRef.current.started
      ? state.clock.elapsedTime - elapsedRef.current.startTime
      : 0;

    const localT = THREE.MathUtils.clamp(
      (elapsed - config.arrival.delay) / config.arrival.duration,
      0,
      1
    );

    lerpTransform(group, config.start, config.end, localT, easing);

    if (localT >= 1) {
      arrivedRef.current = true;
    }

    if (config.spin && arrivedRef.current) {
      applySpin(group, config.spin, delta);
    }

    const opacity = resolveFadeOpacity(elapsed, config.fades);

    for (const t of materialsRef.current) {
      t.material.opacity = opacity;

      if (config.glow && t.standard && t.baseEmissive && t.baseEmissiveIntensity !== undefined) {
        const glowColor = config.glowColor ?? "#38bdf8";
        const targetColor = glowActive ? scratchColor.set(glowColor) : t.baseEmissive;
        const targetIntensity = glowActive ? 1.1 : t.baseEmissiveIntensity;

        t.standard.emissive.lerp(targetColor, delta * 3);
        t.standard.emissiveIntensity = THREE.MathUtils.lerp(
          t.standard.emissiveIntensity,
          targetIntensity,
          delta * 3
        );
      }
    }
  });

  return (
    <primitive
      ref={groupRef}
      object={cloned}
      position={config.start.position}
      rotation={config.start.rotation}
      scale={config.start.scale}
    />
  );
}

useGLTF.preload("/models/cabinet.glb");
useGLTF.preload("/models/motherboard.glb");
useGLTF.preload("/models/cpu.glb");
useGLTF.preload("/models/ram.glb");
useGLTF.preload("/models/gpu.glb");
useGLTF.preload("/models/ssd.glb");
useGLTF.preload("/models/psu.glb");
useGLTF.preload("/models/fan.glb");