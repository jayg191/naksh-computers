"use client";

import { Environment } from "@react-three/drei";

export default function Lights() {
  return (
    <>
      <ambientLight intensity={0.4} color="#a5c9ff" />

      <directionalLight
        position={[5, 8, 5]}
        intensity={1.15}
        color="#ffffff"
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-near={0.5}
        shadow-camera-far={20}
        shadow-camera-left={-4}
        shadow-camera-right={4}
        shadow-camera-top={4}
        shadow-camera-bottom={-4}
      />

      <directionalLight position={[-6, 2, -4]} intensity={1.6} color="#3b82f6" />

      <pointLight position={[0, -1.5, 3]} intensity={0.5} color="#22d3ee" />

      <Environment preset="city" />
    </>
  );
}