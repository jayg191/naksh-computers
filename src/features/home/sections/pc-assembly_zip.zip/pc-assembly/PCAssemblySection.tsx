"use client";

import { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { motion, useInView } from "framer-motion";
import { Cpu, ShieldCheck, Wrench, BadgeCheck } from "lucide-react";

const PCScene = dynamic(() => import("./PCScene"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center">
      <div className="h-10 w-10 animate-spin rounded-full border-2 border-cyan-400/30 border-t-cyan-400" />
    </div>
  ),
});

const features = [
  { icon: BadgeCheck, label: "Genuine Components" },
  { icon: Wrench, label: "Expert Assembly" },
  { icon: Cpu, label: "Performance Tested" },
  { icon: ShieldCheck, label: "Warranty Support" },
];

export default function PCAssemblySection() {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, amount: 0.4 });
  const [play, setPlay] = useState(false);

  useEffect(() => {
    if (isInView) {
      const t = setTimeout(() => setPlay(true), 150);
      return () => clearTimeout(t);
    }
  }, [isInView]);

  return (
    <section
      ref={sectionRef}
      className="relative overflow-hidden bg-[#020617] py-20 sm:py-28"
    >
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-0 h-[600px] w-[600px] -translate-x-1/2 -translate-y-1/3 rounded-full bg-blue-600/20 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-[400px] w-[400px] rounded-full bg-cyan-500/10 blur-[100px]" />
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />
      </div>

      <div className="container relative mx-auto px-4 sm:px-6">
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="relative order-1 h-[360px] w-full overflow-hidden rounded-3xl border border-white/10 bg-white/[0.02] sm:h-[440px] lg:order-1 lg:h-[560px]"
          >
            {isInView && <PCScene play={play} />}
          </motion.div>

          <div className="order-2 lg:order-2">
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-400 sm:text-sm"
            >
              Precision Engineering
            </motion.p>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="mt-4 text-3xl font-bold text-white sm:text-4xl lg:text-5xl"
            >
              Inside Every Powerful Computer
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="mt-5 text-base leading-7 text-slate-300 sm:text-lg sm:leading-8"
            >
              Every high-performance computer begins with carefully selected
              premium components, professionally assembled and tested for
              maximum reliability and performance.
            </motion.p>

            <div className="mt-8 grid grid-cols-2 gap-3 sm:gap-4">
              {features.map((feature, i) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.label}
                    initial={{ opacity: 0, y: 16 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ duration: 0.5, delay: 0.4 + i * 0.08 }}
                    className="group flex items-center gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-3.5 transition-all duration-300 hover:-translate-y-1 hover:border-cyan-400/40 hover:bg-white/[0.06] sm:p-4"
                  >
                    <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 text-white transition-transform duration-300 group-hover:scale-110 sm:size-10">
                      <Icon className="size-4 sm:size-5" strokeWidth={2} />
                    </div>
                    <span className="text-sm font-semibold text-white sm:text-base">
                      {feature.label}
                    </span>
                  </motion.div>
                );
              })}
            </div>

            <motion.div
  initial={{ opacity: 0, y: 20 }}
  animate={isInView ? { opacity: 1, y: 0 } : {}}
  transition={{ duration: 0.6, delay: 0.7 }}
  className="mt-9"
>
  <a
    href={`https://wa.me/919924230096?text=${encodeURIComponent(
      "Hi, I'm interested in building a custom PC. Can I get more details?"
    )}`}
    target="_blank"
    rel="noopener noreferrer"
    className="group inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 px-7 py-3.5 text-sm font-semibold text-white shadow-[0_10px_40px_rgba(37,99,235,0.35)] transition-all duration-300 hover:scale-105 hover:shadow-[0_15px_50px_rgba(37,99,235,0.5)] sm:text-base"
  >
    Build Your Dream PC

    <span className="transition-transform duration-300 group-hover:translate-x-1">
      →
    </span>
  </a>
</motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}