"use client";

import { Suspense, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows } from "@react-three/drei";
import * as THREE from "three";
import Lights from "./Lights";
import CameraRig from "./Camera";
import GLBModel from "./GLBModel";
import { ParticleField, RGBPulseLight, SystemReadyText } from "./Effects";
import {
  ASSEMBLY_SEQUENCE,
  GLOW_START,
  READY_TEXT_START,
  useElapsedRef,
  type ElapsedRef,
} from "./Animations";

interface PCSceneProps {
  play: boolean;
}

interface SceneClockProps {
  play: boolean;
  elapsedRef: ElapsedRef;
  onGlowChange: (active: boolean) => void;
  onReadyChange: (visible: boolean) => void;
}

function SceneClock({ play, elapsedRef, onGlowChange, onReadyChange }: SceneClockProps) {
  useFrame((state) => {
    if (!play) return;

    if (!elapsedRef.current.started) {
      elapsedRef.current.started = true;
      elapsedRef.current.startTime = state.clock.elapsedTime;
    }

    const elapsed = state.clock.elapsedTime - elapsedRef.current.startTime;

    onGlowChange(elapsed >= GLOW_START);
    onReadyChange(elapsed >= READY_TEXT_START);
  });

  return null;
}

function AssemblyRig({ play }: { play: boolean }) {
  const elapsedRef = useElapsedRef();
  const [glowActive, setGlowActive] = useState(false);
  const [readyVisible, setReadyVisible] = useState(false);

  return (
    <>
      <CameraRig play={play} elapsedRef={elapsedRef} />
      <Lights />

      <SceneClock
        play={play}
        elapsedRef={elapsedRef}
        onGlowChange={setGlowActive}
        onReadyChange={setReadyVisible}
      />

      <Suspense fallback={null}>
        <group position={[0, -0.3, 0]}>
          {ASSEMBLY_SEQUENCE.map((config) => (
            <GLBModel
              key={config.id}
              config={config}
              elapsedRef={elapsedRef}
              play={play}
              glowActive={glowActive}
            />
          ))}
        </group>
      </Suspense>

      <RGBPulseLight active={glowActive} />
      <ParticleField active={glowActive} />
      <SystemReadyText visible={readyVisible} />

      <ContactShadows position={[0, -1.15, 0]} opacity={0.55} scale={9} blur={2.6} far={2.5} />
    </>
  );
}

export default function PCScene({ play }: PCSceneProps) {
  return (
    <Canvas
      shadows
      dpr={[1, 1.8]}
      gl={{ antialias: true, alpha: true }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping;
        gl.toneMappingExposure = 1.05;
      }}
    >
      <color attach="background" args={["#020617"]} />
      <fog attach="fog" args={["#020617", 7, 16]} />
      <AssemblyRig play={play} />
    </Canvas>
  );
}